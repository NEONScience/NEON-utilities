ans <- function() .Last.value
