# stack-neon-data.R

require(gdata)
source("functions.R")

pack_name <- "NEON_temp-bio"
location.data <- paste0("data/", pack_name)
zip.name <- paste0(pack_name, ".zip")
zip.filepath <- paste0(location.data, ".zip")

zip.size <- get.filesize(zip.filepath)
zip.files <- list.files.inZip(zip.filepath)
zip.names <- list.zipfiles(zip.filepath)

unzip.zipfile(l1 = location.data, inpath = zip.filepath, outpath = location.data, zname = zip.name, level = "all")
d_fnames_full <- find.datatables(location.data, T)
d_fnames_notfull <- find.datatables(location.data, F)
tables <- find.tables.unique(d_fnames_notfull)
write.tables.all(tables, location.data)
