# messages.R

msg.filesize <- "The size of your file is "
q.folders <- "Would you like files to be organized by year-month, domain-site, or in a single folder? "
error.diffcols.mid <- " has different column names than "
error.diffcols.end <- ". You will get two files rather than one."